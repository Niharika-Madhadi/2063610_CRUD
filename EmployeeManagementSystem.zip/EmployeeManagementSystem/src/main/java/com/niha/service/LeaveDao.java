package com.niha.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.niha.model.EmployeeLeave;

@Service
public interface LeaveDao {
	public void addLeave(EmployeeLeave empLe);
	public List<EmployeeLeave> getAllEmp();
	public EmployeeLeave getEmpById(int id);
	

}
