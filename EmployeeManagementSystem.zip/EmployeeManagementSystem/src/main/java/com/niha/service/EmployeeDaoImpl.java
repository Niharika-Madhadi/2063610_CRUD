package com.niha.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niha.model.Employee;
import com.niha.repository.EmployeeRepository;

@Service
public class EmployeeDaoImpl implements EmployeeDao {
@Autowired
EmployeeRepository EmployeeRepository;

@Override
public void addEmp(Employee emp) {
	EmployeeRepository.save(emp);
	
}

@Override
public List<Employee> getAllEmp() {
	List<Employee> empList=EmployeeRepository.findAll();
	return empList;
}

@Override
public Employee getEmpById(int id) {
	Employee emp=EmployeeRepository.getById(id);
	return emp;
}

@Override
public void updateEmp(Employee emp) {
	EmployeeRepository.save(emp);
	
}

@Override
public void deleteEmp(int empId) {
	EmployeeRepository.deleteById(empId);
	
}

@Override
public Employee validateEmp(Employee emp) {
	Employee emp1=EmployeeRepository.findByLoginData(emp.getEmpName(),emp.getEmpPassword());
	return emp1;
}

}
