package com.niha.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.niha.model.Employee;


@Service
public interface EmployeeDao {
	public void addEmp(Employee emp);
	public List<Employee> getAllEmp();
	public Employee getEmpById(int id);
	public void updateEmp(Employee emp);
	public void deleteEmp(int empId);
	public Employee validateEmp(Employee emp);
}
