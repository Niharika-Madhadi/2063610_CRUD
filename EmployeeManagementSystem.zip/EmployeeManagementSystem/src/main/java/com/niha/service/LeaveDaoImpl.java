package com.niha.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niha.model.EmployeeLeave;
import com.niha.repository.LeaveRepository;

@Service
public class LeaveDaoImpl implements LeaveDao {
	@Autowired
	LeaveRepository leaveRepository;

	@Override
	public void addLeave(EmployeeLeave empLe) {
		leaveRepository.save(empLe);
		
	}

	@Override
	public List<EmployeeLeave> getAllEmp() {
		List<EmployeeLeave> empList=leaveRepository.findAll();
		return empList;
	}

	@Override
	public EmployeeLeave getEmpById(int id) {
		EmployeeLeave emp=leaveRepository.getById(id);
		return emp;
	}

}
