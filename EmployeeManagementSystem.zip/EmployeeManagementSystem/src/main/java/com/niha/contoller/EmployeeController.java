package com.niha.contoller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niha.model.Employee;
import com.niha.service.EmployeeDao;

@Controller
public class EmployeeController {
	
@Autowired
Employee emp;

@Autowired
EmployeeDao empDao;

String msg;
@RequestMapping("/")
public String login(Model model) {
	model.addAttribute("emp", emp);
	model.addAttribute("msg", msg);
	return "index";
}
@RequestMapping("/index")
public String loginagain(Model model) {
	model.addAttribute("emp", emp);
	model.addAttribute("msg", msg);
	return "index";
}
@RequestMapping("validate")
public String validateEmp(@ModelAttribute("emp") Employee emp,  Model mv,HttpSession session) {
	
	Employee emp1 = empDao.validateEmp(emp);
	if(emp1!=null) {
		session.setAttribute("access", emp.getEmpName());
		System.out.println("Login Successfull");
		return "redirect:/home";
	}else {
		System.out.println("Login Failed");
		msg = "Login Failed";
		return "redirect:/";
	}
	
}
@RequestMapping("/registration")
public String showRegistrationForm(Model model) {
	model.addAttribute("emp", emp);
	return "registration";
}

@RequestMapping("submitform")
public ModelAndView saveEmp(@ModelAttribute("emp") Employee emp, ModelAndView mv, @RequestParam("pic") MultipartFile file) throws IOException {
	
	System.out.println("In Save User");
	byte[] empPic = file.getBytes();
	emp.setEmpPic(empPic);
	empDao.addEmp(emp);
	mv.addObject("msg", "User Added Successfully");
	//mv.addObject("user", user);
	mv.setViewName("registration");
	return mv;
}
@RequestMapping("/home")
public ModelAndView showHomepage(ModelAndView m,HttpServletRequest request) {
	HttpSession session=request.getSession();
	String sess = (String)session.getAttribute("access");
	if(sess!=null) {
	m.addObject("emp", emp);
	m.setViewName("home");
	return m;
	}else {
		msg="Session Closed. Login Again";
		m.addObject("msg", msg);
		m.setViewName("redirect:/");
		return m;
	}
}
@RequestMapping("getemp")
public ModelAndView getAllEmp(ModelAndView mv) {
	List<Employee> empList = empDao.getAllEmp();
	mv.addObject("empl", empList);
	mv.addObject("msg", msg);
	mv.setViewName("viewemp");
	return mv;
}
@RequestMapping("viewbyid/{id}")
public ModelAndView getById(@PathVariable int id, ModelAndView mv) {
	Employee emp = empDao.getEmpById(id);
	mv.addObject("emp", emp);
	mv.setViewName("showemp");
	return mv;
}
@RequestMapping("viewbyid/home")
public ModelAndView showHomepage1(ModelAndView m,HttpServletRequest request) {
	HttpSession session=request.getSession();
	String sess = (String)session.getAttribute("access");
	if(sess!=null) {
	m.addObject("emp", emp);
	m.setViewName("redirect:/home");
	return m;
	}else {
		msg="Session Closed. Login Again";
		m.addObject("msg", msg);
		m.setViewName("redirect:/");
		return m;
	}
}
@RequestMapping("viewbyid/getemp")
public ModelAndView getAllEmp1(ModelAndView mv) {
	List<Employee> empList = empDao.getAllEmp();
	mv.addObject("empl", empList);
	mv.addObject("msg", msg);
	mv.setViewName("viewemp");
	return mv;
}
@RequestMapping("updateemp/{id}")
public String getUpdateEmp(@PathVariable int id, Model m) {
	
	Employee emp = empDao.getEmpById(id);
	System.out.println("In Controller : "+emp);
	m.addAttribute("emp", emp);
	return "updateemp";
	
}

@RequestMapping("saveupdate")
public String saveUpdate(@ModelAttribute("emp") Employee emp,@RequestParam("updatedPic") MultipartFile file) throws IOException {

	System.out.println("In Update user");
	byte[] empPic=file.getBytes();
	emp.setEmpPic(empPic);
	empDao.updateEmp(emp);
	return "redirect:/getemp";
	
}



@RequestMapping("deleteemp/{id}")
public String deleteUser(@PathVariable int id) {
	empDao.deleteEmp(id);
	return "redirect:/getemp";
}
@RequestMapping("updateemp/home")
public ModelAndView showHomepage2(ModelAndView m,HttpServletRequest request) {
	HttpSession session=request.getSession();
	String sess = (String)session.getAttribute("access");
	if(sess!=null) {
	m.addObject("emp", emp);
	m.setViewName("redirect:/home");
	return m;
	}else {
		msg="Session Closed. Login Again";
		m.addObject("msg", msg);
		m.setViewName("redirect:/");
		return m;
	}
}

@RequestMapping("logout")
public String destroySession(HttpServletRequest request) {
request.getSession().invalidate();
return "redirect:/";
}





}
