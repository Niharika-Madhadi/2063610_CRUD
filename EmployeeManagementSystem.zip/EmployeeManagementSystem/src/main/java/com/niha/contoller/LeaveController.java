package com.niha.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niha.model.Employee;
import com.niha.model.EmployeeLeave;
import com.niha.service.LeaveDao;

@Controller
public class LeaveController {
@Autowired
EmployeeLeave empLe;
@Autowired
LeaveDao leaveDao;
String msg;
@RequestMapping("/leaveapply")
public String showLeaveForm(Model model) {
	model.addAttribute("empLe", empLe);
	return "leaveapply";
}
@RequestMapping("submitleave")
public ModelAndView saveEmpLeave(@ModelAttribute("empLe") EmployeeLeave empLe, ModelAndView mv){
	
	System.out.println("In Save User Leave");
    leaveDao.addLeave(empLe); 
	mv.addObject("msg", "Leave Added Successfully");
	//mv.addObject("user", user);
	mv.setViewName("leaveapply");
	return mv;
}
@RequestMapping("getleave")
public ModelAndView getAllEmp(ModelAndView mv) {
	List<EmployeeLeave> empList = leaveDao.getAllEmp();
	mv.addObject("empl", empList);
	mv.addObject("msg", msg);
	mv.setViewName("showallleave");
	return mv;
}
@RequestMapping("viewleave/{leaveId}")
public ModelAndView getById(@PathVariable int leaveId, ModelAndView mv) {
	EmployeeLeave empLe = leaveDao.getEmpById(leaveId);
	mv.addObject("empLe", empLe);
	mv.setViewName("showleave");
	return mv;
}
@RequestMapping("viewleave/home")
public String showHomepage1(Model model) {
	model.addAttribute("empLe", empLe);
	return "redirect:/home";
}
}
