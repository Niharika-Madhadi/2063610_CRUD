package com.niha.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="empleave")
@Component
public class EmployeeLeave {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer leaveId;
  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "id")
   private Employee employee;
    private String empname;
    private String startDate;
    private String endDate;
    private String reason;
	public EmployeeLeave() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeeLeave(Integer leaveId, String name, String startDate, String endDate, String reason) {
		super();
		this.leaveId = leaveId;
		this.empname = name;
		this.startDate = startDate;
		this.endDate = endDate;
		this.reason = reason;
	}
	
	public Integer getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(Integer leaveId) {
		this.leaveId = leaveId;
	}

	
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	@Override
	public String toString() {
		return "EmployeeLeave [leaveId=" + leaveId + ", name=" + empname + ", startDate=" + startDate + ", endDate="
				+ endDate + ", reason=" + reason + "]";
	}
	
    
	

}
